package com.kiki.gamingbooster

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent

class GamingBoosterService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d("GamingBooster", "Gaming Booster Active")
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
